from pureples.es_hyperneat.es_hyperneat import ESNetwork, find_pattern 
